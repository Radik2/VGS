import json
import boto3
from datetime import datetime


def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    client = boto3.client('dynamodb')
    
    # Getting the table the table Temperatures object
    air_conditionsTable = dynamodb.Table('air_conditions')
    
    # Getting the current datetime and transforming it to string in the format bellow
    eventDateTime = (datetime.now()).strftime("%Y-%m-%d %H:%M:%S")
    air_station = event['air_station']
    dust_particles = event['dust_particles']
    
    # Putting a try/catch to log to user when some error occurs
    try:
        
        air_conditionsTable.put_item(
           Item={
                'eventDateTime': eventDateTime,
                'air_station': air_station,
                'dust_particles': int(dust_particles)
            }
        )
        
        return {
            'statusCode': 200,
            'body': json.dumps('Data succesfully imported!')
        }
    except:
        print('Closing lambda function')
        return {
                'statusCode': 400,
                'body': json.dumps('Error importing data')
        }